<?php header('Grip-Hold: stream');
      header('Grip-Channel: test');
      header('Content-Type: text/plain'); ?>
[stream open]
